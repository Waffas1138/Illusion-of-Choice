using System;

namespace Utlities
{
    public class Class1
    {
    }
}
