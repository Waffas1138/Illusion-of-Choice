﻿using System;
using System.Collections.Generic;
using System.Text;
using Utilites;

namespace ConsoleUI
{
    class Player
    {
    }
}
